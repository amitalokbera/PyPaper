from discord.ext import commands
import discord
import time
import json 
from backend_launcher import DiscordBackend


with open('credentials.json') as json_file:
    credentials = json.load(json_file)

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())
TOKEN = credentials['bot_token']
start_time = time.time()

global db 
db = DiscordBackend()

@bot.event
async def on_ready():
    print(f'Bot connected as {bot.user}')


@bot.command()
async def status(ctx):
    await ctx.send(f"Bot is online for {round(time.time() - start_time)} seconds")


@bot.command()
async def launch(ctx, url, cat):
    await ctx.send(f"Checking {url}...")
    all_links = db.iterate_links(url)
    if all_links is not None:
        await ctx.send(f"Found {len(all_links)} products")
        await ctx.send(f"Launching in category {cat}")
        db.product_launcher(all_links, cat)
        await ctx.send(f"Done!")

@bot.command()
async def category(ctx):
    wcategory = db.woocommerce_category()
    discord_text = ""
    for i in wcategory:
        discord_text += f"{i} : {wcategory[i]}\n"
    await ctx.send(discord_text)

@bot.command()
async def deleteproduct(ctx, id):
    await ctx.send(f"Deleting product with id {id}")
    dres = db.delete_product(id)
    if dres is False:
        await ctx.send(f"Product with id {id} not found")
    else:
        await ctx.send(f"Product with id {id} deleted")

@bot.command()
async def commandhelp(ctx):
    await ctx.send("Hello! I am a bot that can launch your product from backend. \n To launch your backend, type !launch <url> <category_1> <category_2>")

bot.run(TOKEN)