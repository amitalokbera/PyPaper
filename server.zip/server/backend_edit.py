from scrapper import Scrapper
import mysql.connector
from tqdm import tqdm 
import json
import pandas as pd
import warnings 
import re
import woocommerce
import ast
from discordwebhook import Discord

warnings.filterwarnings('ignore')

global credentials 
with open('credentials.json') as json_file:
    credentials = json.load(json_file)

global wordpress_api 
woocommerce_api = woocommerce.API(
            url="https://www.smpestores.com",
            consumer_key=credentials['woocommerce_key'],
            consumer_secret=credentials['woocommerce_secret'],
            wp_api=True,
            version="wc/v3",
            timeout = 1000
        )

def fetch_float(data):
    return float(''.join(re.findall(r'\d+\.?\d*', str(data))))

def fetch_data():
    mydb = mysql.connector.connect(
                user=credentials['db_user'], 
                password=credentials['db_password'], 
                host='68.178.145.128', 
                database=credentials['db_name'])
    sql_cmd = ('SELECT * FROM smp_backend.product_table')
    df = pd.read_sql_query(sql_cmd, mydb)
    df['sale_price_outside'] = df['sale_price_outside'].apply(fetch_float)
    df['regular_price'] = df['regular_price'].apply(fetch_float)
    df['sale_price'] = df['sale_price'].apply(fetch_float)
    mydb.close()
    return df

def update_sql_price(pid, price):
    mydb = mysql.connector.connect(
                user=credentials['db_user'], 
                password=credentials['db_password'], 
                host='68.178.145.128', 
                database=credentials['db_name'])
    mycursor = mydb.cursor()
    sql_cmd = f"UPDATE smp_backend.product_table SET sale_price = {price} WHERE pid = {pid}"
    mycursor.execute(sql_cmd)
    mydb.commit()
    mydb.close()

def update_sql_stock(pid, stock):
    mydb = mysql.connector.connect(
                user=credentials['db_user'], 
                password=credentials['db_password'], 
                host='68.178.145.128', 
                database=credentials['db_name'])
    mycursor = mydb.cursor()
    sql_cmd = f"UPDATE smp_backend.product_table SET stock_status = '{str(stock)}' WHERE pid = {pid}"
    print(sql_cmd)
    mycursor.execute(sql_cmd)
    mydb.commit()
    mydb.close()



def discord_webhook_price(webhook_url, p_data, p_link, res_link, pid , old_price, new_price):
        webhook = Discord(url=webhook_url)
        webhook.post(embeds=[{
            "title": p_data['title'],
            "description": f"[Scrapped Link]({p_link}) | [Product Link]({res_link})",
            "color": 0x00ff00,
            "fields": [
                {
                    "name": "Old Selling Price",
                    "value": str(old_price) ,
                    "inline": False
                },
                {
                    "name": "New Selling Price",
                    "value": str(new_price),
                    "inline": False
                },
                {
                    "name": "Stock",
                    "value": True,
                    "inline": False
                },
                {
                    "name": "Product ID",
                    "value": str(pid),
                    "inline": False
                }

            ],
            "image": {
                "url": p_data['images'][0]
            },
            "thumbnail": {
                "url": p_data['images'][0]
            },
            "footer": {
                "text": "Powered by SMP Bot"
            }
        }])

def discord_webhook_stock(webhook_url, p_data, p_link, res_link, pid , old_stock, new_stock):
        webhook = Discord(url=webhook_url)
        webhook.post(embeds=[{
            "title": p_data['title'],
            "description": f"[Scrapped Link]({p_link}) | [Product Link]({res_link})",
            "color": 0x00ff00,
            "fields": [
                {
                    "name": "Selling Price",
                    "value": p_data['selling_price'] ,
                    "inline": False
                },
                {
                    "name": "MRP Price",
                    "value": p_data['mrp_price'],
                    "inline": False
                },
                {
                    "name": "Old Stock",
                    "value": old_stock,
                    "inline": False
                },
                {
                    "name": "New Stock",
                    "value": new_stock,
                    "inline": False
                },
                {
                    "name": "Product ID",
                    "value": pid,
                    "inline": False
                }

            ],
            "image": {
                "url": p_data['images'][0]
            },
            "thumbnail": {
                "url": p_data['images'][0]
            },
            "footer": {
                "text": "Powered by SMP Bot"
            }
        }])

def main():
    while True:
        df = fetch_data()
        for index, row in tqdm(df.iterrows(), total=df.shape[0]):
            if row['domain'] == 'ltonlinestore':
                sc = Scrapper()
                sc.create_driver()
                p_data = sc.ltstoreonline(row['permalink_scrapped'])
                sc.close_driver()
                print(p_data['stock'] != ast.literal_eval(row['stock_status']), p_data['stock'], ast.literal_eval(row['stock_status']))
                if fetch_float(p_data['selling_price']) < float(row['sale_price']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"sale_price": str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"]))})
                    update_sql_price(row['pid'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                    discord_webhook_price(credentials['price_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], row['sale_price'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                if p_data['stock'] != ast.literal_eval(row['stock_status']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"stock_status": p_data['stock']})
                    update_sql_stock(row['pid'], str(p_data['stock']))
                    discord_webhook_stock(credentials['stock_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], ast.literal_eval(row['stock_status']), p_data['stock'])
            elif row['domain'] == 'zilla':
                sc = Scrapper()
                sc.create_driver()
                p_data = sc.zilla(row['permalink_scrapped'])
                sc.close_driver()
                if fetch_float(p_data['selling_price']) < float(row['sale_price']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"sale_price": str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"]))})
                    update_sql_price(row['pid'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                    discord_webhook_price(credentials['price_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], row['sale_price'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                if p_data['stock'] != ast.literal_eval(row['stock_status']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"stock_status": p_data['stock']})
                    update_sql_stock(row['pid'], str(p_data['stock']))
                    discord_webhook_stock(credentials['stock_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], ast.literal_eval(row['stock_status']), p_data['stock'])
            elif row['domain'] == 'industrybuying':
                sc = Scrapper()
                sc.create_driver()
                p_data = sc.industrybuying(row['permalink_scrapped'])
                sc.close_driver()
                if fetch_float(p_data['selling_price']) < float(row['sale_price']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"sale_price": str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"]))})
                    update_sql_price(row['pid'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                    discord_webhook_price(credentials['price_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], row['sale_price'], str(fetch_float(p_data['selling_price']) - float(credentials["reduce_amt"])))
                if p_data['stock'] != ast.literal_eval(row['stock_status']):
                    woocommerce_api.put(f"products/{row['pid']}", data={"stock_status": p_data['stock']})
                    update_sql_stock(row['pid'], str(p_data['stock']))
                    discord_webhook_stock(credentials['stock_update_webhook'], p_data, row['permalink_scrapped'], row['permalink'], row['pid'], ast.literal_eval(row['stock_status']), p_data['stock'])


if __name__ == "__main__":
    main()



