import os 
import requests 
from scrapper import Scrapper
import json 
from bs4 import BeautifulSoup
import random 
from tqdm import tqdm 
import woocommerce
import mysql.connector
import base64
from io import BytesIO
from PIL import Image 
import ftplib
import time
from discordwebhook import Discord

global credentials

with open('credentials.json') as json_file:
    credentials = json.load(json_file)

class DiscordBackend:
    def __init__(self) -> None:
        self.woocommerce_api = woocommerce.API(
            url="https://www.smpestores.com",
            consumer_key=credentials['woocommerce_key'],
            consumer_secret=credentials['woocommerce_secret'],
            wp_api=True,
            version="wc/v3",
            timeout = 1000
        )
        while True:
            self.proxies = requests.get(credentials['proxy_link']).text.replace('\r', '').split('\n')
            self.proxy = random.choice(self.proxies)
            self.ip = self.proxy.split(':')[0]
            self.port = self.proxy.split(':')[1]
            self.proxy_username = self.proxy.split(':')[2]
            self.proxy_password = self.proxy.split(':')[3]
            self.ip_link = "http://httpbin.org/ip"
            self.req_proxy = {"http": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip +
                            ":"+self.port, "https": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip+":"+self.port}
            self.response = requests.get(self.ip_link, proxies=self.req_proxy)
            if self.response.json()['origin'] == self.ip:
                print(self.response.json())
                break 
        self.req_proxy = {"http": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip +
                            ":"+self.port, "https": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip+":"+self.port}
    
    def discord_webhook(self, webhook_url, p_data, p_link, res_link, pid):
        self.webhook = Discord(url=webhook_url)
        self.webhook.post(embeds=[{
            "title": p_data['title'],
            "description": f"[Scrapped Link]({p_link}) | [Product Link]({res_link})",
            "color": 0x00ff00,
            "fields": [
                {
                    "name": "Selling Price",
                    "value": p_data['selling_price'] ,
                    "inline": False
                },
                {
                    "name": "MRP Price",
                    "value": p_data['mrp_price'],
                    "inline": False
                },
                {
                    "name": "Stock",
                    "value": True,
                    "inline": False
                },
                {
                    "name": "Product ID",
                    "value": pid,
                    "inline": False
                }

            ],
            "image": {
                "url": p_data['images'][0]
            },
            "thumbnail": {
                "url": p_data['images'][0]
            },
            "footer": {
                "text": "Powered by SMP Bot"
            }
        }])

    def get_links(self, url):
        try:
            if "ltonlinestore" in url:
                self.headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'} 
                self.r = requests.get(url, headers=self.headers, proxies=self.req_proxy)
                self.soup = BeautifulSoup(self.r.content, 'html.parser')
                self.all_links = [x['href'] for x in self.soup.find_all('a', attrs= {'class':'grid-product__title'})]
            if "zilla" in url:
                self.headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'} 
                self.r = requests.get(url, headers=self.headers, proxies=self.req_proxy)
                self.soup = BeautifulSoup(self.r.content, 'html.parser')
                self.all_links = [x.a['href'] for x in self.soup.find_all('div', attrs={'class':'center_block'})]
            if "industrybuying" in url:
                self.headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'} 
                self.r = requests.get(url, headers=self.headers, proxies=self.req_proxy)
                self.soup = BeautifulSoup(self.r.content, 'html.parser')
                self.all_links = ["https://www.industrybuying.com" + x['href'] for x in self.soup.find_all('a', attrs={'class':'prFeatureName'})]
            if len(self.all_links) > 0:
                return self.all_links
            else:
                return None 
        except Exception as e:
            print(e)
            None

    def iterate_links(self, link):
        try:
            self.product_links = []
            self.first_link =  None 
            if "ltonlinestore" in link:
                if "?offset=" not in link:
                    self.link = link + "?offset="
                    self.counter = 0
                else:
                    self.counter = int(link.split("?offset=")[1])
                    self.link = link.split("?offset=")[0] + "?offset="
                print('Iterating through LTStoreonline links')
                for i in tqdm(range(1, 1000)):
                    self.url = self.link + str(self.counter)
                    self.counter += 60
                    temp = self.get_links(self.url)
                    if temp is not None:
                        self.product_links += temp
                    else:
                        break
            if "zilla" in link:
                if "?p=" not in link:
                    self.link = link + "?p="
                    self.start_index = 1
                else:
                    self.start_index = int(link.split("?p=")[1])
                    self.link = link.split("?p=")[0] + "?p="
                print('Iterating through Zilla links')
                for i in tqdm(range(self.start_index, 1000)):
                    self.url = self.link + str(i) + "&n=50"
                    temp = self.get_links(self.url)
                    if temp[0] not in self.product_links:
                        self.product_links += temp
                    else:
                        break
            if "industrybuying" in link:
                if "?page=" not in link:
                    self.link = link + "?page="
                    self.start_index = 1
                else:
                    self.start_index = int(link.split("?page=")[1])
                    self.link = link.split("?page=")[0] + "?page="
                print('Iterating through IndustryBuying links')
                for i in tqdm(range(self.start_index, 1000)):
                    self.url = self.link + str(i)
                    temp = self.get_links(self.url)
                    if temp is not None:
                        self.product_links += temp
                    else:
                        break
            if len(self.product_links) > 0:
                return self.product_links
            else:
                return None

        except Exception as e:
            print(e) 
            pass 

    def delete_product(self, product_id):
        try:
            self.woocommerce_api.delete(f"products/{product_id}")
            self.cnx = mysql.connector.connect(
                user=credentials['db_user'], password=credentials['db_password'], host='68.178.145.128', database=credentials['db_name'])
            self.cursor = self.cnx.cursor()
            self.cursor.execute(f"DELETE FROM product_table WHERE pid = {product_id}")
            self.cnx.commit()
            self.cursor.close()
            self.cnx.close()
            return True
        except:
            return False
    
    def woocommerce_category(self):
        self.wcategories = self.woocommerce_api.get("products/categories", params={"per_page": 100}).json()
        self.category = {} 
        for i in self.wcategories:
            self.category[i['name']] = i['id']
        return self.category

    def woocommerce_launch(self, p_data, cat1):
        try:
            self.push_images = []
            for i in range(len(p_data['images'])):
                if p_data['images'][i].endswith('.webp'):
                    self.response = requests.get(p_data['images'][i])
                    self.image = Image.open(BytesIO(self.response.content)).convert("RGB")
                    self.image.save(f"image{i}.jpg", "JPEG")
                    with open(f"image{i}.jpg", "rb") as image_file:
                        self.ftp_hostname = "files.000webhost.com"
                        self.ftp_username = "smpestores"
                        self.ftp_password = "pUfEtJiPzgBi8n6"
                        self.session = ftplib.FTP(self.ftp_hostname, self.ftp_username, self.ftp_password)
                        self.session.storbinary(f'STOR image{i}.jpg', image_file)
                        self.session.quit()
                    self.push_images.append({'src' : f"https://smpestores.000webhostapp.com/image{i}.jpg"})
                else:
                    self.push_images.append({'src' : p_data['images'][i]})
            self.push_images = self.push_images[:3]
            self.desc_data = ""
            if p_data['product_attributes'] != "":
                self.desc_data += p_data['product_attributes']
            elif p_data['description'] != "":
                self.desc_data += p_data['description']
            self.woocommerce_payload = {
                "name": p_data['title'],
                "type": "simple",
                "regular_price": p_data['mrp_price'],
                "sale_price": p_data['selling_price'],
                "description": str(self.desc_data),
                "short_description": str(p_data['infocard']),
                "sku": "SMP_" + str(int(time.time())),
                "categories": [
                    {
                        "id": str(cat1)
                    }
                ],
                "images": self.push_images,
                "attributes": [
                    {
                        "name": "Brand",
                        "options": [
                            p_data['brand']
                        ]
                    },
                ]

            }
            self.res = self.woocommerce_api.post("products", self.woocommerce_payload, params={"timeout": 1000}).json()
            if self.res['id']:
                return self.res
            else:
                return None
        except Exception as e:
            print(e)
            pass 

    def table_update(self, p_data, res, p_link):
        try:
            self.cnx = mysql.connector.connect(
                user=credentials['db_user'], password=credentials['db_password'], host='68.178.145.128', database=credentials['db_name'])
            self.cursor = self.cnx.cursor()
            self.domain = '' 
            if 'ltonlinestore' in p_link:
                self.domain = 'ltonlinestore'
            if 'zilla' in p_link:
                self.domain = 'zilla'
            if 'industrybuying' in p_link:
                self.domain = 'industrybuying'
            self.insert_stmt = (f"INSERT INTO product_table (permalink, status, sku, regular_price, sale_price, stock_status, permalink_scrapped, stock_scrapped, sale_price_outside, domain, pid) VALUES ( '{res['permalink']}', '{res['status']}', '{res['sku']}', '{res['regular_price']}', '{res['sale_price']}', '{res['purchasable']}', '{p_link}', '{p_data['stock']}', '{p_data['selling_price']}', '{self.domain}', '{res['id']}')")
            self.cursor.execute(self.insert_stmt)
            self.cnx.commit()
            self.cursor.close()
            self.cnx.close()
        except Exception as e:
            print(e)
            pass 
    
    def product_launcher(self, bulk_links, cat1):
        for i in bulk_links:
            try:
                sc = Scrapper()
                sc.create_driver()
                if 'ltonlinestore' in i:
                    self.p_data = sc.ltstoreonline(i)
                if 'zilla' in i:
                    self.p_data = sc.zilla(i)
                if 'industrybuying' in i:
                    self.p_data = sc.industrybuying(i)
                sc.close_driver()
                print(self.p_data)
                if self.p_data is not None:
                    self.wresult = self.woocommerce_launch(self.p_data, cat1)
                    if self.wresult is not None:
                        print(f"Product {self.p_data['title']} launched successfully")
                        self.discord_webhook(credentials['new_product_webhook'], self.p_data, i, self.wresult['permalink'], self.wresult['id'])
                        self.table_update(self.p_data, self.wresult, i)
            except Exception as e:
                pass
        
        