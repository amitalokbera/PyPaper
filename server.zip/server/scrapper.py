import requests
import urllib
import json, random
import time
from bs4 import BeautifulSoup
import os 
import ftplib
from PIL import Image
import random 
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

os.makedirs('images', exist_ok=True)

global credentials

with open('credentials.json') as json_file:
    credentials = json.load(json_file)


class Scrapper():
    def __init__(self) -> None:
        self.driver = None
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
        

    def create_driver(self):
        while True:
            self.proxies = requests.get(credentials['proxy_link']).text.replace('\r', '').split('\n')
            self.proxy = random.choice(self.proxies)
            self.ip = self.proxy.split(':')[0]
            self.port = self.proxy.split(':')[1]
            self.proxy_username = self.proxy.split(':')[2]
            self.proxy_password = self.proxy.split(':')[3]
            self.ip_link = "http://httpbin.org/ip"
            self.req_proxy = {"http": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip +
                            ":"+self.port, "https": "http://"+self.proxy_username+":"+self.proxy_password+"@"+self.ip+":"+self.port}
            self.response = requests.get(self.ip_link, proxies=self.req_proxy)
            if self.response.json()['origin'] == self.ip:
                break
        self.chrome_options = Options()
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
        self.chrome_options.add_argument(f'user-agent={self.user_agent}')
        self.chrome_options.add_argument("--log-level=3")
        self.chrome_options.add_argument('--allow-insecure-localhost')
        self.chrome_options.add_argument('--ignore-certificate-errors')
        self.chrome_options.add_argument('--lang=en_US')
        self.chrome_options.add_argument('--headless')
        self.chrome_options.add_argument('--ignore-ssl-errors')
        self.chrome_options.add_experimental_option("excludeSwitches", ['enable-automation'])
        self.chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        self.capabilities = DesiredCapabilities.CHROME
        self.capabilities["proxy"] = {
            "httpProxy": self.ip+":"+self.port,
            "ftpProxy": self.ip+":"+self.port,
            "sslProxy": self.ip+":"+self.port,
            "noProxy": None,
            "proxyType": "MANUAL",
            "class": "org.openqa.selenium.Proxy",
            "autodetect": False,
            "socksUsername": self.proxy_username,
            "socksPassword": self.proxy_password
        }
        self.driver = webdriver.Chrome(options=self.chrome_options, desired_capabilities=self.capabilities)
        self.driver.set_page_load_timeout(600)
    
    def close_driver(self):
        if self.driver is not None:
            self.driver.quit()


    def ltstoreonline(self, url):
        try:
            self.driver.get(url)
        except:
            pass
        time.sleep(5)
        self.current_len = len(self.driver.page_source)
        while True:
            time.sleep(2)
            if len(self.driver.page_source) == self.current_len:
                self.html_data = self.driver.page_source
                break
            self.current_len = len(self.driver.page_source)
        self.soup = BeautifulSoup(self.html_data, 'html.parser')
        self.title = self.soup.find('h1',attrs={'class':'product-details__product-title ec-header-h3'}).text
        self.selling_price = self.soup.find('span',attrs={'class':'details-product-price__value ec-price-item notranslate'}).text
        self.mrp_price = self.soup.find('span', attrs={'class':'details-product-price-compare__value ec-text-muted notranslate'}).text
        try:
            self.infocard = self.soup.find('div',attrs={'class':'product-details-module product-details__subtitle'}).text
        except:
            self.infocard = "<b> We always sell genuine and new sealed pack products. </b>"
        try:
            self.product_attributes = self.soup.find_all('div',attrs={'class':'details-product-attribute'})
            self.product_attributes = "\n".join([x.text.strip().replace('\n',' ') for x in self.product_attributes])
        except:
            self.product_attributes = ''
        try:
            self.description = self.soup.find('div',attrs={'class':'product-details-module product-details__general-info'})
            self.description.find('div',attrs={'class':'product-details-module__btn-more'}).decompose()
            self.description.find('div',attrs={'class':'product-details-module__title ec-header-h6'}).decompose()
        except:
            self.description = ''
        self.data_json = json.loads(self.soup.find('script',attrs={'type':'application/ld+json'}).text)
        self.images = self.data_json['image']
        self.stock = [True if "InStock" in x else False for x in [self.data_json['offers']['availability']]][0]
        self.brand = self.title.split()[0]
        self.data = {"title":self.title,
                "brand":self.brand,
                "selling_price":self.selling_price,
                "mrp_price":self.mrp_price,
                "infocard":self.infocard.strip(),
                "product_attributes":self.product_attributes,
                "description":self.description,
                "images":self.images,
                "stock":self.stock}
        return self.data

    
        
    def zilla(self, url):
        self.header  = {'user-agent': self.user_agent}
        self.r = requests.get(url, headers=self.header, proxies=self.req_proxy)
        self.soup = BeautifulSoup(self.r.text, 'html.parser')
        self.title = self.soup.h1.text
        self.infocard = self.soup.find('div',attrs={'id':'short_description_content'}).text
        self.price = self.soup.find('div',attrs={'class':'price'}).text.strip()
        self.spec_table = self.soup.find('table',attrs={'class':'spec'}).text.strip()
        self.description = self.soup.find('div',attrs={'id':'idTab1'}).text.strip()
        self.stock = self.soup.find('p', attrs={'id':'add_to_cart'}) is not None
        self.product_no = [x for x in self.description.splitlines()]
        self.part_no_index = None
        for x in range(len(self.product_no)):
            if "Part Number" in self.product_no[x]:
                self.part_no_index = x + 1
                break
        self.part_no = self.product_no[self.part_no_index]
        self.smp_part_no = "SMP" + self.part_no[2:] 
        self.description = self.description.replace(self.part_no, self.smp_part_no).replace('ZILLA', 'SMP eStores').replace('zilla', 'SMP eStores')
        self.link = f"https://ltonlinestore.com/search?keyword={urllib.parse.quote_plus(self.title.split(',')[0])}"
        try:
            self.driver.get(self.link)
        except:
            pass
        self.current_len = len(self.driver.page_source)
        while True:
            time.sleep(2)
            if len(self.driver.page_source) == self.current_len:
                self.html_data = self.driver.page_source
                break
            self.current_len = len(self.driver.page_source)
        self.soup = BeautifulSoup(self.html_data, 'html.parser')
        self.ltlink = self.soup.findAll('a',attrs={'class':'grid-product__title'})
        for i in self.ltlink:
            try:
                self.r = requests.get(i['href'], headers=self.header, proxies=self.req_proxy)
                self.soup = BeautifulSoup(self.r.text, 'html.parser')
                self.data_json = json.loads(self.soup.find('script',attrs={'type':'application/ld+json'}).text)
                self.images = self.data_json['image']
                break
            except:
                pass
        self.brand = self.title.split()[0]
        self.data = {"title":self.title,
                "brand":self.brand,
                "selling_price":self.price,
                "mrp_price":self.price,
                "infocard":self.infocard.strip(),
                "product_attributes":self.spec_table,
                "description":self.description,
                "images":self.images,
                "stock":self.stock}
        return self.data

    def industrybuying(self, url):
        self.headers = {'user-agent': self.user_agent}
        self.driver.get(url)
        self.current_len = len(self.driver.page_source)
        while True:
            time.sleep(2)
            if len(self.driver.page_source) == self.current_len:
                self.html_data = self.driver.page_source
                break
            self.current_len = len(self.driver.page_source)
        self.soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        self.title = self.soup.find('h1').text.strip()
        self.selling_price = self.soup.find('span',attrs={'class':'price'}).text.strip().splitlines()[1].strip()
        self.infocard = self.soup.find('div',attrs={'class':'features'})
        self.infocard.find('a',attrs={'class':'more AH_more_details'}).decompose()
        self.infocard = [x for x in self.infocard.text.strip().splitlines() if len(x) != 0]
        for i in range(2, len(self.infocard)):
            try:
                if i % 2 == 0:
                    self.infocard[i-1] = self.infocard[i-1] + " " + self.infocard[i]
                    self.infocard[i] = ''
            except:
                pass
        self.infocard = "\n".join([x for x in self.infocard if len(x) != 0])
        try:
            self.mrp_price = self.soup.find('del',attrs={'id':'AH_ListPrice'}).text.strip()
        except:
            self.mrp_price = self.selling_price 
        self.description  = self.soup.find('div',attrs={'id':'description'}).text.strip()
        self.images_link = ["https:" + self.soup.find('img', attrs={'class':'mainImg zoom_img'})['src']]
        self.images = self.images_link
        self.brand = self.soup.find('div',attrs={'class':'by'}).text.strip().replace('by','').strip()
        self.stock = self.soup.find('a', attrs={'class':'bigButton addToCart'}) is not None
        self.data = {"title":self.title,
                "selling_price":self.selling_price,
                "mrp_price":self.mrp_price,
                "infocard":self.infocard,
                "product_attributes":'',
                "description":self.description,
                "images":self.images,
                "stock":self.stock,
                "brand":self.brand}
        return self.data